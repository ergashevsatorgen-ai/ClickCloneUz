package uz.clickclone

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlin.math.abs

// ---------------------------------------------------------------- CATEGORY

@Composable
fun CategoryScreen(nav: NavController) {
    ScreenRoot {
        TopBar(Flow.category, onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            (catalog[Flow.category] ?: emptyList()).forEach { svc ->
                WCard(Modifier.fillMaxWidth(), onClick = { openService(nav, Flow.category, svc) }) {
                    Row(Modifier.padding(horizontal = 18.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Bg), contentAlignment = Alignment.Center) {
                            T(svc.name.take(1), 22, FontWeight.Bold, Blue)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column(Modifier.weight(1f)) {
                            T(svc.name, 19, FontWeight.Medium)
                            T(svc.sub, 14, color = Grey)
                        }
                        Icon(Icons.Filled.KeyboardArrowRight, null, tint = Grey)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ---------------------------------------------------------------- PAY FORM

@Composable
fun PayFormScreen(nav: NavController) {
    val isPhone = Flow.category == "Mobil operatorlar"
    var account by remember { mutableStateOf(Flow.prefillAccount) }
    var amount by remember { mutableStateOf(Flow.prefillAmount) }
    var cardId by remember { mutableStateOf(Store.cards.firstOrNull()?.id ?: "") }
    var picker by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val card = Store.card(cardId)
    val amt = amount.toLongOrNull() ?: 0L
    val accOk = if (isPhone) account.length == 9 else account.length >= 4
    val valid = accOk && amt >= 500 && card != null
    ScreenRoot {
        TopBar(Flow.service, onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T(Flow.svcSub, 16, color = Grey)
                Spacer(Modifier.width(8.dp))
                DemoChip()
            }
            WCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
                    T(if (isPhone) "Telefon raqami" else "Hisob raqami / ID", 14, color = Grey)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (isPhone) { T("+998 ", 22, FontWeight.Medium) }
                        BasicTextField(
                            account, { account = it.filter { c -> c.isDigit() }.take(if (isPhone) 9 else 20) }, singleLine = true,
                            textStyle = TextStyle(fontSize = 22.sp, color = Ink, fontWeight = FontWeight.Medium),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            cursorBrush = SolidColor(Blue), modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            T("To'lov kartasi", 16, color = Grey)
            if (card != null) CardTile(card, onClick = { picker = true })
            if (amount.isNotEmpty() && amt < 500) T("Minimal summa: 500 so'm", 14, color = Red)
        }
        BottomPanel {
            AmountInput(amount, { amount = it })
            QuickChips(listOf(5000L, 10000L, 25000L, 50000L, 100000L)) { amount = it.toString() }
            Box(Modifier.padding(horizontal = 16.dp)) { BigButton("To'lash", enabled = valid) { confirm = true } }
        }
    }
    if (picker) CardPicker(onPick = { cardId = it; picker = false }, onDismiss = { picker = false })
    if (confirm && card != null) {
        ConfirmDialog(
            "To'lovni tasdiqlang",
            listOf(
                "Xizmat" to Flow.service,
                "Hisob" to (if (isPhone) "+998$account" else account),
                "Karta" to (card.bank + " *" + card.number.takeLast(4))
            ),
            amt,
            onConfirm = {
                confirm = false
                val tx = Store.pay(cardId, Flow.service, Flow.svcSub, if (isPhone) "+998$account" else account, amt)
                Flow.lastTxId = tx.id
                nav.navigate("result") { popUpTo("main") }
            },
            onDismiss = { confirm = false }
        )
    }
}

// ---------------------------------------------------------------- TRANSFER

@Composable
fun TransferScreen(nav: NavController) {
    val mode = Flow.transferMode
    val contact = Flow.contact
    var fromId by remember { mutableStateOf(Store.cards.firstOrNull()?.id ?: "") }
    var toId by remember { mutableStateOf(Store.cards.firstOrNull { it.id != Store.cards.firstOrNull()?.id }?.id ?: "") }
    var num by remember { mutableStateOf(Flow.prefillAccount) }
    var amount by remember { mutableStateOf("") }
    var pickFrom by remember { mutableStateOf(false) }
    var pickTo by remember { mutableStateOf(false) }
    var confirm by remember { mutableStateOf(false) }
    val from = Store.card(fromId)
    val toCard = Store.card(toId)
    val amt = amount.toLongOrNull() ?: 0L
    val title = when (mode) {
        "own" -> "Kartalarim orasida"
        "loan" -> "Qarzga berish"
        "request" -> "Pul so'rash"
        else -> contact?.name ?: "Kartaga o'tkazma"
    }
    val recipientOk = when (mode) {
        "own" -> toCard != null && toId != fromId
        "contact" -> contact != null
        else -> num.length in listOf(9, 12, 16)
    }
    val recName = when (mode) {
        "own" -> toCard?.bank ?: ""
        "contact" -> contact?.name ?: ""
        else -> if (num.length == 16) "Karta *" + num.takeLast(4) else "+" + (if (num.length == 9) "998$num" else num)
    }
    val recNumber = when (mode) {
        "own" -> toCard?.number ?: ""
        "contact" -> contact?.mask ?: ""
        else -> num
    }
    val valid = recipientOk && amt >= 500 && from != null
    val btn = if (mode == "request") "So'rash" else "O'tkazish"

    ScreenRoot {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Ink, modifier = Modifier.rotate(90f))
            }
            if (mode == "contact" && contact != null) {
                InitialsAvatar(contact.initials, 48.dp)
                Spacer(Modifier.width(10.dp))
            }
            Column(Modifier.weight(1f)) {
                T(title, 20, FontWeight.Bold, maxLines = 1)
                if (mode == "contact" && contact != null) T(contact.mask, 15, color = Grey)
                else DemoChip()
            }
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Blue).clickable { nav.navigate("history") }.padding(horizontal = 18.dp, vertical = 10.dp)
            ) { T("Tarix", 16, FontWeight.Medium, Color.White) }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (from != null) CardTile(from, onClick = { pickFrom = true })
                    when (mode) {
                        "own" -> if (toCard != null) CardTile(toCard, onClick = { pickTo = true })
                        "contact" -> RecipientTile(contact?.initials ?: "", contact?.name ?: "", contact?.mask ?: "")
                        else -> WCard(Modifier.fillMaxWidth(), radius = 24.dp) {
                            Row(Modifier.padding(horizontal = 16.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                                InitialsAvatar("+", 56.dp)
                                Spacer(Modifier.width(16.dp))
                                Column(Modifier.weight(1f)) {
                                    Box {
                                        if (num.isEmpty()) T("Karta yoki telefon raqami", 17, color = DisabledGrey, maxLines = 1)
                                        BasicTextField(
                                            num, { num = it.filter { c -> c.isDigit() }.take(16) }, singleLine = true,
                                            textStyle = TextStyle(fontSize = 22.sp, color = Ink, fontWeight = FontWeight.Bold),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            cursorBrush = SolidColor(Blue), modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                    T("9, 12 (telefon) yoki 16 (karta) xonali raqam", 13, color = Grey)
                                }
                            }
                        }
                    }
                }
                Box(
                    Modifier.align(Alignment.CenterEnd).padding(end = 40.dp).size(54.dp).clip(CircleShape).background(Bg),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.KeyboardArrowDown, null, tint = Ink, modifier = Modifier.size(30.dp))
                    }
                }
            }
            if (mode == "own" && toId == fromId) T("Boshqa kartani tanlang", 14, color = Red)
            if (mode == "own" && Store.cards.size < 2) T("Kartalar orasida o'tkazish uchun kamida 2 ta karta kerak", 14, color = Red)
        }
        BottomPanel {
            AmountInput(amount, { amount = it })
            QuickChips(listOf(10000L, 50000L, 100000L, 250000L, 500000L)) { amount = it.toString() }
            Box(Modifier.padding(horizontal = 16.dp)) { BigButton(btn, enabled = valid) { confirm = true } }
        }
    }
    if (pickFrom) CardPicker(onPick = { fromId = it; pickFrom = false }, onDismiss = { pickFrom = false })
    if (pickTo) CardPicker(onPick = { toId = it; pickTo = false }, onDismiss = { pickTo = false })
    if (confirm && from != null) {
        ConfirmDialog(
            if (mode == "request") "So'rovni tasdiqlang" else "O'tkazmani tasdiqlang",
            listOf(
                "Qaysi kartadan" to (from.bank + " *" + from.number.takeLast(4)),
                "Qabul qiluvchi" to (if (recName.isEmpty()) recNumber else "$recName  $recNumber")
            ),
            amt,
            onConfirm = {
                confirm = false
                val tx = when (mode) {
                    "own" -> Store.transferOwn(fromId, toId, amt)
                    "request" -> Store.request(fromId, recName, recNumber, amt)
                    else -> Store.pay(
                        fromId, if (mode == "loan") "Qarz berish" else "Kartaga o'tkazma", "O'tkazmalar",
                        recNumber, amt, "transfer", recName
                    )
                }
                Flow.lastTxId = tx.id
                nav.navigate("result") { popUpTo("main") }
            },
            onDismiss = { confirm = false }
        )
    }
}

@Composable
fun RecipientTile(initials: String, name: String, mask: String) {
    WCard(Modifier.fillMaxWidth(), radius = 24.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
            InitialsAvatar(initials, 56.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                T(name.uppercase(), 22, FontWeight.Bold, maxLines = 1)
                T(mask, 18, color = Grey)
            }
        }
    }
}

// ---------------------------------------------------------------- TOP UP

@Composable
fun TopUpScreen(nav: NavController) {
    var cardId by remember { mutableStateOf(if (Flow.topupCard.isNotEmpty()) Flow.topupCard else Store.cards.firstOrNull()?.id ?: "") }
    var amount by remember { mutableStateOf("") }
    var picker by remember { mutableStateOf(false) }
    val card = Store.card(cardId)
    val amt = amount.toLongOrNull() ?: 0L
    ScreenRoot {
        TopBar("Demo balansni to'ldirish", onBack = { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                DemoChip(); Spacer(Modifier.width(8.dp))
                T("Faqat sinov uchun, haqiqiy pul kirmaydi", 14, color = Grey)
            }
            if (card != null) CardTile(card, onClick = { picker = true })
        }
        BottomPanel {
            AmountInput(amount, { amount = it })
            QuickChips(listOf(50000L, 100000L, 500000L, 1000000L)) { amount = it.toString() }
            Box(Modifier.padding(horizontal = 16.dp)) {
                BigButton("To'ldirish", enabled = amt >= 1000 && card != null) {
                    val tx = Store.topUp(cardId, amt)
                    Flow.lastTxId = tx.id
                    nav.navigate("result") { popUpTo("main") }
                }
            }
        }
    }
    if (picker) CardPicker(onPick = { cardId = it; picker = false }, onDismiss = { picker = false })
}

// ---------------------------------------------------------------- RESULT / RECEIPT

@Composable
fun DetailRow(k: String, v: String) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        T(k, 16, color = Grey)
        T(v, 22, FontWeight.Medium)
    }
}

@Composable
fun ResultScreen(nav: NavController) {
    val tx = Store.txs.firstOrNull { it.id == Flow.lastTxId }
    ScreenRoot {
        if (tx == null) {
            Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                T("Natija topilmadi", 20, FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                BigButton("Yopish") { nav.popBackStack("main", false) }
            }
        } else {
            val ok = tx.status != "Muvaffaqiyatsiz"
            val card = Store.card(tx.cardId)
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))
                Box(Modifier.size(96.dp).clip(CircleShape).background(if (ok) GreenSoft else RedSoft), contentAlignment = Alignment.Center) {
                    Icon(if (ok) Icons.Filled.Check else Icons.Filled.Close, null, tint = if (ok) GreenOk else Red, modifier = Modifier.size(56.dp))
                }
                Spacer(Modifier.height(20.dp))
                T(
                    when {
                        !ok -> "Amaliyot bajarilmadi"
                        tx.kind == "request" -> "So'rov yuborildi"
                        tx.kind == "topup" -> "Balans to'ldirildi"
                        else -> "Muvaffaqiyatli bajarildi"
                    },
                    24, FontWeight.Bold, align = TextAlign.Center
                )
                Spacer(Modifier.height(8.dp))
                Money(fmt(abs(tx.amount)), 38)
                if (!ok) {
                    Spacer(Modifier.height(8.dp))
                    val need = abs(tx.amount)
                    val msg = if (need <= 0) "Summa noto'g'ri kiritildi."
                    else "Kartada mablag' yetarli emas. Mavjud demo balans: ${fmt(card?.balance ?: 0L)} so'm."
                    T(msg, 16, color = Red, align = TextAlign.Center)
                }
                Spacer(Modifier.height(10.dp))
                DemoChip()
                Spacer(Modifier.height(20.dp))
                WCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
                        DetailRow("Xizmat", tx.title)
                        if (tx.account != "-" && tx.account.isNotEmpty()) DetailRow("Hisob / qabul qiluvchi", tx.account)
                        DetailRow("Tranzaksiya raqami", tx.id)
                        DetailRow("Sana va vaqt", fullLabel(tx.time))
                        if (card != null) DetailRow("Karta", card.bank + " *" + card.number.takeLast(4))
                    }
                }
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                LightButton("Chekni ko'rish") { Flow.receiptId = tx.id; nav.navigate("receipt") }
                BigButton("Yopish") { nav.popBackStack("main", false) }
            }
        }
    }
}

fun receiptText(tx: Tx): String =
    "CLICK CLONE - DEMO CHEK (haqiqiy emas)\n" +
        "${tx.title}\nSumma: ${fmt(abs(tx.amount))} so'm\nHolat: ${tx.status}\n" +
        "Sana: ${fullLabel(tx.time)}\nTranzaksiya: ${tx.id}\nQabul qiluvchi: ${tx.counterparty} ${tx.account}"

@Composable
fun ReceiptScreen(nav: NavController) {
    val tx = Store.txs.firstOrNull { it.id == Flow.receiptId }
    val ctx = LocalContext.current
    fun share() {
        if (tx == null) return
        val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, receiptText(tx))
        }
        ctx.startActivity(android.content.Intent.createChooser(i, "Demo chekni yuborish"))
    }
    ScreenRoot {
        if (tx == null) {
            TopBar("Chek", { nav.popBackStack() })
            T("Chek topilmadi", 18, modifier = Modifier.padding(24.dp))
        } else {
            val card = Store.card(tx.cardId)
            val ok = tx.status != "Muvaffaqiyatsiz"
            val statusColor = if (ok) GreenOk else Red
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    Column(Modifier.fillMaxWidth().background(Color.White).padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(60.dp).clip(RoundedCornerShape(14.dp)).background(Bg), contentAlignment = Alignment.Center) {
                                Icon(
                                    if (tx.kind == "topup") Icons.Filled.Add else if (tx.kind == "pay") Icons.Filled.Receipt else Icons.Filled.SwapHoriz,
                                    null, tint = Blue, modifier = Modifier.size(34.dp)
                                )
                            }
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                T(tx.title, 26, FontWeight.Bold, maxLines = 2)
                                T(tx.subtitle, 17, color = Grey)
                            }
                            Icon(
                                Icons.Filled.Close, null, tint = Ink,
                                modifier = Modifier.size(44.dp).clip(CircleShape).background(Bg).clickable { nav.popBackStack() }.padding(10.dp)
                            )
                        }
                        Spacer(Modifier.height(20.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                T("To'lov summasi", 17, color = Grey)
                                Money(fmt(abs(tx.amount)), 36)
                            }
                            Box(
                                Modifier.clip(RoundedCornerShape(50)).background(if (ok) GreenSoft else RedSoft).padding(horizontal = 18.dp, vertical = 12.dp)
                            ) { T(if (ok) tx.status else "Muvaffaqiyatsiz", 19, FontWeight.Bold, statusColor) }
                        }
                        Spacer(Modifier.height(16.dp))
                        T("To'lov kartasi", 17, color = Grey)
                        Spacer(Modifier.height(8.dp))
                        if (card != null) {
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Bg).padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CardArt(card)
                                Spacer(Modifier.width(16.dp))
                                Column {
                                    T(card.number.replace(" ", "").let { it.take(6) + "******" + it.takeLast(4) }, 20, FontWeight.Bold)
                                    T(card.bank.uppercase(), 16, color = Grey)
                                }
                            }
                        }
                    }
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                        DetailRow("Operatsiya sanasi va vaqti", fullLabel(tx.time))
                        DetailRow("Tranzaksiya raqami", tx.id)
                        DetailRow("Yuboruvchi", Store.name.uppercase())
                        when (tx.kind) {
                            "transfer", "own", "request" -> {
                                DetailRow("Qabul qiluvchining kartasi / raqami", tx.account)
                                DetailRow("Qabul qiluvchi", tx.counterparty.uppercase())
                            }
                            "pay" -> {
                                DetailRow("Xizmat", tx.title)
                                DetailRow("Hisob raqami", tx.account)
                            }
                            else -> DetailRow("Manba", tx.counterparty)
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            ActionCircle(Icons.Filled.Receipt, "Xarid\ncheki") { share() }
                            ActionCircle(Icons.Filled.Share, "Yuborish") { share() }
                            ActionCircle(Icons.Filled.PieChart, "To'lovlar\ntarixi") { nav.popBackStack() }
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                }
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "DEMO", fontSize = 120.sp, fontWeight = FontWeight.Black, color = Orange.copy(alpha = 0.13f),
                        modifier = Modifier.rotate(-25f)
                    )
                }
            }
        }
    }
}

@Composable
fun ActionCircle(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.width(96.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(80.dp).clip(CircleShape).background(Color.White).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(8.dp))
        T(label, 15, align = TextAlign.Center)
    }
}

// ---------------------------------------------------------------- HISTORY / NOTIFICATIONS

@Composable
fun HistoryScreen(nav: NavController) {
    val list = Store.txs.filter { it.kind == "transfer" || it.kind == "own" || it.kind == "request" }
    ScreenRoot {
        TopBar("O'tkazmalar tarixi", { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (list.isEmpty()) T("Hozircha o'tkazmalar yo'q", 17, color = Grey, modifier = Modifier.padding(top = 24.dp).fillMaxWidth(), align = TextAlign.Center)
            list.forEach { t -> TxRow(t) { Flow.receiptId = t.id; nav.navigate("receipt") } }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun NotificationsScreen(nav: NavController) {
    ScreenRoot {
        TopBar("Mening Click", { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            WCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    T("Demo rejim", 19, FontWeight.Bold)
                    T("Click Clone sinov ilovasi. Balans va to'lovlar faqat shu telefonda saqlanadi.", 15, color = Grey)
                }
            }
            Store.txs.take(15).forEach { t ->
                WCard(Modifier.fillMaxWidth(), onClick = { Flow.receiptId = t.id; nav.navigate("receipt") }) {
                    Column(Modifier.padding(18.dp)) {
                        T(t.title + " - " + t.status, 17, FontWeight.Medium)
                        T(fmt(t.amount) + " so'm  •  " + dayLabel(t.time) + " " + timeLabel(t.time), 14, color = Grey)
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ---------------------------------------------------------------- CARDS / PROFILE / SETTINGS

@Composable
fun CardsScreen(nav: NavController) {
    var add by remember { mutableStateOf(false) }
    ScreenRoot {
        TopBar("Kartalar va hamyon", { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                DemoChip(); Spacer(Modifier.width(8.dp))
                T("Faqat demo kartalar. Haqiqiy karta kiritilmaydi.", 14, color = Grey)
            }
            Store.cards.forEach { c ->
                CardTile(c, chevron = false)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { LightButton("Balansni to'ldirish") { Flow.topupCard = c.id; nav.navigate("topup") } }
                    Box(Modifier.weight(1f)) { LightButton("O'tkazish") { Flow.contact = null; openTransfer(nav, "own") } }
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        Box(Modifier.padding(16.dp)) { BigButton("Demo karta qo'shish") { add = true } }
    }
    if (add) {
        AlertDialog(
            onDismissRequest = { add = false }, containerColor = Color.White,
            title = { T("Demo karta turi", 20, FontWeight.Bold) },
            text = {
                Column {
                    listOf("Demo Uzcard" to 0xFF2D6CDF, "Demo Visa" to 0xFF1A1F71, "Demo Humo" to 0xFF1FCB5A, "Demo Bank" to 0xFF438A8D).forEach { (n, col) ->
                        TextButton(onClick = { Store.addCard(n, col); add = false }) { T(n, 18, color = Blue) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { add = false }) { T("Bekor qilish", 16, color = Grey) } }
        )
    }
}

@Composable
fun ProfileScreen(nav: NavController, onLogout: () -> Unit) {
    var editName by remember { mutableStateOf(false) }
    var nm by remember { mutableStateOf(Store.name) }
    ScreenRoot {
        TopBar("Profil", { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            WCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    InitialsAvatar(Store.name.take(1).uppercase(), 72.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            T(Store.name, 22, FontWeight.Bold, maxLines = 1)
                            Spacer(Modifier.width(6.dp))
                            Icon(Icons.Filled.Verified, null, tint = Blue, modifier = Modifier.size(22.dp))
                        }
                        T(Store.phone, 17, color = Grey)
                        Spacer(Modifier.height(4.dp))
                        DemoChip()
                    }
                }
            }
            WCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    T("Umumiy demo balans", 15, color = Grey)
                    Money(fmt(Store.total()), 30)
                    Spacer(Modifier.height(8.dp))
                    T("Tranzaksiyalar soni: ${Store.txs.size}", 15, color = Grey)
                }
            }
            ProfileItem(Icons.Filled.Edit, "Ismni o'zgartirish") { nm = Store.name; editName = true }
            ProfileItem(Icons.Filled.CreditCard, "Kartalarim") { nav.navigate("cards") }
            ProfileItem(Icons.Filled.Settings, "Sozlamalar") { nav.navigate("settings") }
            ProfileItem(Icons.Filled.ExitToApp, "Chiqish") { onLogout() }
        }
    }
    if (editName) {
        AlertDialog(
            onDismissRequest = { editName = false }, containerColor = Color.White,
            title = { T("Ism", 20, FontWeight.Bold) },
            text = { OutlinedTextField(value = nm, onValueChange = { nm = it.take(24) }, singleLine = true) },
            confirmButton = { TextButton(onClick = { if (nm.isNotBlank()) { Store.name = nm.trim(); Store.save() }; editName = false }) { T("Saqlash", 16, FontWeight.Bold, Blue) } },
            dismissButton = { TextButton(onClick = { editName = false }) { T("Bekor qilish", 16, color = Grey) } }
        )
    }
}

@Composable
fun ProfileItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    WCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(horizontal = 20.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue)
            Spacer(Modifier.width(16.dp))
            T(label, 19, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.KeyboardArrowRight, null, tint = Grey)
        }
    }
}

@Composable
fun SettingsScreen(nav: NavController) {
    var pinDlg by remember { mutableStateOf(false) }
    var newPin by remember { mutableStateOf("") }
    var resetDlg by remember { mutableStateOf(false) }
    var about by remember { mutableStateOf(false) }
    ScreenRoot {
        TopBar("Sozlamalar", { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            WCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    T("Balansni yashirish", 19, modifier = Modifier.weight(1f))
                    Switch(checked = Store.hideBalance, onCheckedChange = { Store.hideBalance = it; Store.save() })
                }
            }
            ProfileItem(Icons.Filled.Lock, "PIN-kodni o'zgartirish") { newPin = ""; pinDlg = true }
            ProfileItem(Icons.Filled.Add, "Demo balansni to'ldirish") { Flow.topupCard = ""; nav.navigate("topup") }
            ProfileItem(Icons.Filled.Refresh, "Demo ma'lumotlarni tiklash") { resetDlg = true }
            ProfileItem(Icons.Filled.Info, "Dastur haqida") { about = true }
        }
    }
    if (pinDlg) {
        AlertDialog(
            onDismissRequest = { pinDlg = false }, containerColor = Color.White,
            title = { T("Yangi PIN-kod", 20, FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = newPin, onValueChange = { newPin = it.filter { c -> c.isDigit() }.take(4) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    label = { Text("4 xonali PIN") }
                )
            },
            confirmButton = { TextButton(onClick = { if (newPin.length == 4) { Store.changePin(newPin); pinDlg = false } }) { T("Saqlash", 16, FontWeight.Bold, Blue) } },
            dismissButton = { TextButton(onClick = { pinDlg = false }) { T("Bekor qilish", 16, color = Grey) } }
        )
    }
    if (resetDlg) {
        AlertDialog(
            onDismissRequest = { resetDlg = false }, containerColor = Color.White,
            title = { T("Tiklash", 20, FontWeight.Bold) },
            text = { T("Demo kartalar, balans (1 000 000 so'm) va tarix boshlang'ich holatga qaytariladi.", 16) },
            confirmButton = { TextButton(onClick = { Store.resetDemoData(); resetDlg = false }) { T("Tiklash", 16, FontWeight.Bold, Red) } },
            dismissButton = { TextButton(onClick = { resetDlg = false }) { T("Bekor qilish", 16, color = Grey) } }
        )
    }
    if (about) InfoDialog(
        "Click Clone (demo)",
        "Bu sinov ilovasi. Haqiqiy pul, haqiqiy karta, haqiqiy SMS yoki bank hisoblari ishlatilmaydi. Barcha ma'lumotlar faqat shu telefonda saqlanadi. Ilova Click xizmatiga tegishli emas."
    ) { about = false }
}
