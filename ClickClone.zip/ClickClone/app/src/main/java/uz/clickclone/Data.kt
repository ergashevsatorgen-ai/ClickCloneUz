package uz.clickclone

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

data class DemoCard(val id: String, val bank: String, val number: String, val balance: Long, val color: Long)

data class Tx(
    val id: String,
    val time: Long,
    val title: String,
    val subtitle: String,
    val amount: Long,
    val status: String,
    val cardId: String,
    val kind: String,          // pay, transfer, own, topup, request
    val counterparty: String,
    val account: String,
    val note: String
)

data class Contact(val name: String, val mask: String, val initials: String)
data class Svc(val name: String, val sub: String)

val demoContacts = listOf(
    Contact("Aziz K.", "99890******11", "AK"),
    Contact("Madina S.", "99893******03", "MS"),
    Contact("Bobur M.", "99897******40", "BM")
)

val catalog: LinkedHashMap<String, List<Svc>> = linkedMapOf(
    "Mobil operatorlar" to listOf(
        Svc("Ucell", "Mobil aloqa"), Svc("Beeline", "Mobil aloqa"), Svc("Mobiuz", "Mobil aloqa"),
        Svc("Uzmobile", "Mobil aloqa"), Svc("Humans", "Mobil aloqa")
    ),
    "Internet va TV" to listOf(
        Svc("MyXvest.ru", "Xosting va domenlar"), Svc("Sayt.uz", "Xosting va domenlar"),
        Svc("Sarkor Telecom", "Internet"), Svc("Uztelecom", "Internet"), Svc("Turon Telecom", "Internet")
    ),
    "Davlat xizmatlari va DYHXX (GAI)" to listOf(
        Svc("GAI jarimalari", "Davlat xizmatlari"), Svc("Soliq to'lovlari", "Davlat xizmatlari"),
        Svc("Davlat boji", "Davlat xizmatlari")
    ),
    "Kommunal to'lovlar" to listOf(
        Svc("Elektroenergiya (Jismoniy shaxs)", "Kommunal to'lovlar"), Svc("Tabiiy gaz", "Kommunal to'lovlar"),
        Svc("Suv ta'minoti", "Kommunal to'lovlar"), Svc("Issiqlik ta'minoti", "Kommunal to'lovlar"),
        Svc("Chiqindi", "Kommunal to'lovlar")
    ),
    "Mikrokredit va muddatli to'lovlar" to listOf(
        Svc("Demo Mikrokredit", "Mikrokredit"), Svc("Demo Muddatli to'lov", "Muddatli to'lov")
    )
)

object Flow {
    var category by mutableStateOf("")
    var service by mutableStateOf("")
    var svcSub by mutableStateOf("")
    var prefillAccount by mutableStateOf("")
    var prefillAmount by mutableStateOf("")
    var contact by mutableStateOf<Contact?>(null)
    var transferMode by mutableStateOf("manual")
    var topupCard by mutableStateOf("")
    var lastTxId by mutableStateOf("")
    var receiptId by mutableStateOf("")
}

val monthNames = listOf(
    "yanvar", "fevral", "mart", "aprel", "may", "iyun",
    "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
)

fun fmt(v: Long): String {
    val s = kotlin.math.abs(v).toString()
    val sb = StringBuilder()
    for ((i, c) in s.withIndex()) {
        if (i > 0 && (s.length - i) % 3 == 0) sb.append(' ')
        sb.append(c)
    }
    return (if (v < 0) "-" else "") + sb.toString()
}

private fun cal(t: Long): Calendar = Calendar.getInstance().apply { timeInMillis = t }
fun dayLabel(t: Long): String { val c = cal(t); return "${c.get(Calendar.DAY_OF_MONTH)} ${monthNames[c.get(Calendar.MONTH)]}" }
fun timeLabel(t: Long): String { val c = cal(t); return String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)) }
fun fullLabel(t: Long): String {
    val c = cal(t)
    return String.format(
        Locale.US, "%02d.%02d.%04d %02d:%02d",
        c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1, c.get(Calendar.YEAR),
        c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)
    )
}

private fun sha(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(("click-clone-demo:$s").toByteArray()).joinToString("") { "%02x".format(it) }

object Store {
    private var prefs: SharedPreferences? = null

    var phone by mutableStateOf("")
    var name by mutableStateOf("Demo Foydalanuvchi")
    var registered by mutableStateOf(false)
    var unlocked by mutableStateOf(false)
    var hideBalance by mutableStateOf(false)
    private var pinHash = ""
    val cards = mutableStateListOf<DemoCard>()
    val txs = mutableStateListOf<Tx>()
    val favorites = mutableStateListOf<String>()

    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.getSharedPreferences("click_clone_demo", Context.MODE_PRIVATE)
        load()
    }

    private fun load() {
        val raw = prefs?.getString("data", null) ?: return
        try {
            val o = JSONObject(raw)
            phone = o.optString("phone")
            name = o.optString("name", name)
            pinHash = o.optString("pin")
            registered = o.optBoolean("registered")
            hideBalance = o.optBoolean("hide")
            cards.clear()
            val ca = o.optJSONArray("cards") ?: JSONArray()
            for (i in 0 until ca.length()) {
                val c = ca.getJSONObject(i)
                cards.add(DemoCard(c.getString("id"), c.getString("bank"), c.getString("number"), c.getLong("balance"), c.getLong("color")))
            }
            txs.clear()
            val ta = o.optJSONArray("txs") ?: JSONArray()
            for (i in 0 until ta.length()) {
                val t = ta.getJSONObject(i)
                txs.add(
                    Tx(
                        t.getString("id"), t.getLong("time"), t.getString("title"), t.getString("subtitle"),
                        t.getLong("amount"), t.getString("status"), t.getString("cardId"), t.getString("kind"),
                        t.optString("cp"), t.optString("account"), t.optString("note")
                    )
                )
            }
            favorites.clear()
            val fa = o.optJSONArray("fav") ?: JSONArray()
            for (i in 0 until fa.length()) favorites.add(fa.getString(i))
        } catch (e: Exception) {
            // buzilgan ma'lumot bo'lsa e'tiborsiz qoldiriladi
        }
    }

    fun save() {
        val o = JSONObject()
        o.put("phone", phone)
        o.put("name", name)
        o.put("pin", pinHash)
        o.put("registered", registered)
        o.put("hide", hideBalance)
        val ca = JSONArray()
        cards.forEach {
            ca.put(JSONObject().put("id", it.id).put("bank", it.bank).put("number", it.number).put("balance", it.balance).put("color", it.color))
        }
        o.put("cards", ca)
        val ta = JSONArray()
        txs.forEach {
            ta.put(
                JSONObject().put("id", it.id).put("time", it.time).put("title", it.title).put("subtitle", it.subtitle)
                    .put("amount", it.amount).put("status", it.status).put("cardId", it.cardId).put("kind", it.kind)
                    .put("cp", it.counterparty).put("account", it.account).put("note", it.note)
            )
        }
        o.put("txs", ta)
        val fa = JSONArray()
        favorites.forEach { fa.put(it) }
        o.put("fav", fa)
        prefs?.edit()?.putString("data", o.toString())?.apply()
    }

    fun newTxId(): String {
        var id: String
        do {
            id = (1_000_000_000L + Random.nextLong(8_000_000_000L)).toString()
        } while (txs.any { it.id == id })
        return id
    }

    fun card(id: String): DemoCard? = cards.firstOrNull { it.id == id }
    fun total(): Long = cards.sumOf { it.balance }
    fun checkPin(p: String): Boolean = sha(p) == pinHash
    fun changePin(p: String) { pinHash = sha(p); save() }

    private fun setBalance(id: String, nb: Long) {
        val i = cards.indexOfFirst { it.id == id }
        if (i >= 0) cards[i] = cards[i].copy(balance = nb)
    }

    private fun seed() {
        cards.clear(); txs.clear(); favorites.clear()
        cards.add(DemoCard("c1", "Demo Bank", "9999 00** **** 0035", 1_000_000L, 0xFF438A8D))
        cards.add(DemoCard("c2", "Demo Humo", "9999 01** **** 9487", 0L, 0xFF1FCB5A))
        txs.add(
            Tx(newTxId(), System.currentTimeMillis(), "Boshlang'ich demo balans", "Balansni to'ldirish", 1_000_000L,
                "Muvaffaqiyatli", "c1", "topup", "Demo tizim", "-", "")
        )
        favorites.add("Aziz K.")
    }

    fun registerUser(ph: String, pin: String) {
        phone = ph
        pinHash = sha(pin)
        registered = true
        unlocked = true
        seed()
        save()
    }

    fun resetDemoData() { seed(); save() }

    fun resetAll() {
        phone = ""; name = "Demo Foydalanuvchi"; pinHash = ""; registered = false; unlocked = false
        cards.clear(); txs.clear(); favorites.clear()
        prefs?.edit()?.clear()?.apply()
    }

    fun logout() { unlocked = false }

    fun pay(
        cardId: String, title: String, subtitle: String, account: String, amount: Long,
        kind: String = "pay", counterparty: String = title, note: String = ""
    ): Tx {
        val c = card(cardId)
        val ok = c != null && amount > 0 && c.balance >= amount
        val tx = Tx(
            newTxId(), System.currentTimeMillis(), title, subtitle, -amount,
            if (ok) "Muvaffaqiyatli" else "Muvaffaqiyatsiz", cardId, kind, counterparty, account, note
        )
        if (ok && c != null) setBalance(cardId, c.balance - amount)
        txs.add(0, tx); save()
        return tx
    }

    fun transferOwn(fromId: String, toId: String, amount: Long): Tx {
        val f = card(fromId)
        val t = card(toId)
        val ok = f != null && t != null && fromId != toId && amount > 0 && f.balance >= amount
        val tx = Tx(
            newTxId(), System.currentTimeMillis(), "Kartalarim orasida", "O'tkazmalar", -amount,
            if (ok) "Muvaffaqiyatli" else "Muvaffaqiyatsiz", fromId, "own",
            t?.bank ?: "-", t?.number ?: "-", ""
        )
        if (ok && f != null && t != null) {
            setBalance(fromId, f.balance - amount)
            setBalance(toId, t.balance + amount)
        }
        txs.add(0, tx); save()
        return tx
    }

    fun topUp(cardId: String, amount: Long): Tx {
        val c = card(cardId)
        val ok = c != null && amount > 0
        val tx = Tx(
            newTxId(), System.currentTimeMillis(), "Balansni to'ldirish", "Demo balans", amount,
            if (ok) "Muvaffaqiyatli" else "Muvaffaqiyatsiz", cardId, "topup", "Demo tizim", "-", ""
        )
        if (ok && c != null) setBalance(cardId, c.balance + amount)
        txs.add(0, tx); save()
        return tx
    }

    fun request(cardId: String, who: String, number: String, amount: Long): Tx {
        val tx = Tx(
            newTxId(), System.currentTimeMillis(), "Pul so'rash", "O'tkazmalar", amount,
            if (amount > 0) "Yuborildi" else "Muvaffaqiyatsiz", cardId, "request", who, number, ""
        )
        txs.add(0, tx); save()
        return tx
    }

    fun addCard(bank: String, color: Long) {
        val last = Random.nextInt(1000, 9999)
        cards.add(DemoCard("c" + System.currentTimeMillis(), bank, "9999 02** **** $last", 0L, color))
        save()
    }

    fun toggleFavorite(n: String) {
        if (favorites.contains(n)) favorites.remove(n) else favorites.add(n)
        save()
    }
}
