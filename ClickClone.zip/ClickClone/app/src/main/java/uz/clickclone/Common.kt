package uz.clickclone

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.Canvas
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg = Color(0xFFECF1F5)
val Blue = Color(0xFF0077FF)
val Ink = Color(0xFF141414)
val Grey = Color(0xFF8A94A0)
val GreenOk = Color(0xFF12B76A)
val GreenSoft = Color(0xFFD7F5E3)
val RedSoft = Color(0xFFFFE1DE)
val Orange = Color(0xFFFF6B00)
val Red = Color(0xFFE5392B)
val DisabledGrey = Color(0xFFC5CAD1)

@Composable
fun ClickTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue, background = Bg, surface = Color.White,
            onSurface = Ink, onBackground = Ink
        ),
        content = content
    )
}

@Composable
fun T(
    text: String, size: Int = 16, weight: FontWeight = FontWeight.Normal, color: Color = Ink,
    modifier: Modifier = Modifier, align: TextAlign? = null, maxLines: Int = Int.MAX_VALUE
) {
    Text(
        text, modifier, color = color, fontSize = size.sp, fontWeight = weight,
        textAlign = align, maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun Money(v: String, size: Int = 28, color: Color = Ink, weight: FontWeight = FontWeight.Bold, modifier: Modifier = Modifier) {
    Text(
        buildAnnotatedString {
            withStyle(SpanStyle(fontSize = size.sp, fontWeight = weight)) { append(v) }
            withStyle(SpanStyle(fontSize = (size * 0.55f).sp, fontWeight = FontWeight.Normal)) { append(" so'm") }
        },
        modifier, color = color
    )
}

@Composable
fun ScreenRoot(imeAware: Boolean = true, bottomInset: Boolean = true, content: @Composable ColumnScope.() -> Unit) {
    var m = Modifier.fillMaxSize().background(Bg).statusBarsPadding()
    if (bottomInset) m = m.navigationBarsPadding()
    if (imeAware) m = m.imePadding()
    Column(m, content = content)
}

@Composable
fun TopBar(title: String, onBack: () -> Unit, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp).height(48.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Ink) }
        T(title, 20, FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1)
        trailing()
    }
}

@Composable
fun WCard(
    modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, radius: Dp = 20.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val base = modifier.clip(RoundedCornerShape(radius)).background(Color.White)
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(m, content = content)
}

@Composable
fun BigButton(text: String, enabled: Boolean = true, color: Color = Blue, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp))
            .background(if (enabled) color else DisabledGrey)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(text, 20, FontWeight.Bold, Color.White) }
}

@Composable
fun LightButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp)).background(Color.White)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(text, 20, FontWeight.Bold, Blue) }
}

@Composable
fun DemoChip(modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(50)).background(Orange).padding(horizontal = 10.dp, vertical = 3.dp)) {
        T("DEMO", 11, FontWeight.Bold, Color.White)
    }
}

@Composable
fun ClickMark(size: Dp, ring: Color, hole: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension
        rotate(45f) {
            drawRoundRect(ring, Offset(s * 0.17f, s * 0.17f), Size(s * 0.66f, s * 0.66f), CornerRadius(s * 0.2f))
            drawRoundRect(hole, Offset(s * 0.37f, s * 0.37f), Size(s * 0.26f, s * 0.26f), CornerRadius(s * 0.08f))
        }
    }
}

@Composable
fun IconBadge(icon: ImageVector, tint: Color, size: Dp = 56.dp, bg: Color = Color.Transparent) {
    Box(Modifier.size(size).clip(RoundedCornerShape(16.dp)).background(bg), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.6f))
    }
}

@Composable
fun InfoDialog(title: String, msg: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        confirmButton = { TextButton(onClick = onDismiss) { T("OK", 16, FontWeight.Bold, Blue) } },
        title = { T(title, 20, FontWeight.Bold) },
        text = { T(msg, 16) }
    )
}

@Composable
fun ConfirmDialog(
    title: String, rows: List<Pair<String, String>>, amount: Long,
    onConfirm: () -> Unit, onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        title = { T(title, 22, FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                rows.forEach { (k, v) -> Column { T(k, 13, color = Grey); T(v, 17, FontWeight.Medium) } }
                Money(fmt(amount), 30)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    DemoChip(); Spacer(Modifier.width(8.dp))
                    T("Haqiqiy pul yechilmaydi", 13, color = Grey)
                }
            }
        },
        confirmButton = { TextButton(onClick = onConfirm) { T("Tasdiqlash", 17, FontWeight.Bold, Blue) } },
        dismissButton = { TextButton(onClick = onDismiss) { T("Bekor qilish", 17, color = Grey) } }
    )
}

object ThousandsTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val out = StringBuilder()
        val o2t = IntArray(s.length + 1)
        val t2o = ArrayList<Int>()
        for (i in s.indices) {
            if (i > 0 && (s.length - i) % 3 == 0) {
                t2o.add(i)
                out.append(' ')
            }
            o2t[i] = out.length
            t2o.add(i)
            out.append(s[i])
        }
        o2t[s.length] = out.length
        t2o.add(s.length)
        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int = o2t[offset.coerceIn(0, s.length)]
            override fun transformedToOriginal(offset: Int): Int = t2o[offset.coerceIn(0, t2o.size - 1)]
        }
        return TransformedText(AnnotatedString(out.toString()), mapping)
    }
}

@Composable
fun AmountInput(digits: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { try { focus.requestFocus() } catch (e: Exception) { } }
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(
            value = digits,
            onValueChange = { onChange(it.filter { c -> c.isDigit() }.take(10).trimStart('0')) },
            singleLine = true,
            textStyle = TextStyle(fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.End),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            visualTransformation = ThousandsTransformation,
            cursorBrush = SolidColor(Blue),
            modifier = Modifier.width(IntrinsicSize.Min).widthIn(min = 28.dp).focusRequester(focus),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterEnd) {
                    if (digits.isEmpty()) T("0", 44, FontWeight.Bold, DisabledGrey)
                    inner()
                }
            }
        )
        Spacer(Modifier.width(8.dp))
        T("so'm", 28, FontWeight.Bold, Grey)
    }
}

@Composable
fun QuickChips(values: List<Long>, onPick: (Long) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        values.forEach { v ->
            Box(Modifier.clip(RoundedCornerShape(24.dp)).background(Bg).clickable { onPick(v) }.padding(horizontal = 24.dp, vertical = 14.dp)) {
                T(fmt(v), 18)
            }
        }
    }
}

@Composable
fun BottomPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)).background(Color.White)
            .padding(top = 28.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        content = content
    )
}

@Composable
fun CardArt(card: DemoCard, modifier: Modifier = Modifier) {
    Box(modifier.size(width = 80.dp, height = 50.dp).clip(RoundedCornerShape(10.dp)).background(Color(card.color))) {
        ClickMark(20.dp, Color.White.copy(alpha = 0.85f), Color(card.color), Modifier.align(Alignment.TopStart).padding(5.dp))
        T("*" + card.number.takeLast(4), 12, FontWeight.Bold, Color.White, Modifier.align(Alignment.BottomStart).padding(6.dp))
    }
}

@Composable
fun CardTile(card: DemoCard, onClick: (() -> Unit)? = null, chevron: Boolean = true, modifier: Modifier = Modifier) {
    WCard(modifier.fillMaxWidth(), onClick = onClick, radius = 24.dp) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            CardArt(card)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Money(fmt(card.balance), 22)
                T(card.bank.uppercase(), 15, color = Grey)
            }
            if (chevron) Icon(Icons.Filled.KeyboardArrowDown, null, tint = Ink)
        }
    }
}

@Composable
fun CardPicker(onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Bg,
        confirmButton = {},
        title = { T("Kartani tanlang", 20, FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Store.cards.forEach { c -> CardTile(c, onClick = { onPick(c.id) }, chevron = false) }
            }
        }
    )
}

@Composable
fun SearchBox(value: String, onChange: (String) -> Unit, hint: String = "Qidiruv", modifier: Modifier = Modifier, trailing: @Composable () -> Unit = {}) {
    Row(
        modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(16.dp)).background(Color.White).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = Grey)
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) T(hint, 18, color = DisabledGrey)
            BasicTextField(
                value, onChange, singleLine = true,
                textStyle = TextStyle(fontSize = 18.sp, color = Ink),
                cursorBrush = SolidColor(Blue), modifier = Modifier.fillMaxWidth()
            )
        }
        trailing()
    }
}

@Composable
fun InitialsAvatar(initials: String, size: Dp = 60.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(Bg), contentAlignment = Alignment.Center) {
        T(initials, (size.value * 0.33f).toInt(), FontWeight.Medium)
    }
}

@Composable
fun TxRow(tx: Tx, onClick: () -> Unit) {
    val icon = when (tx.kind) {
        "topup" -> Icons.Filled.Add
        "transfer", "own" -> Icons.Filled.SwapHoriz
        "request" -> Icons.Filled.Phone
        else -> Icons.Filled.Receipt
    }
    val failed = tx.status == "Muvaffaqiyatsiz"
    val income = tx.amount > 0 && tx.kind != "request"
    WCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(Bg), Alignment.Center) {
                Icon(icon, null, tint = Blue)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                T(tx.title, 18, FontWeight.Bold, maxLines = 2)
                T(tx.subtitle, 15, color = Grey, maxLines = 1)
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Money(
                    (if (income) "+" else "") + fmt(tx.amount), 18,
                    color = if (failed) Red else if (income) GreenOk else Ink
                )
                T(
                    if (failed) "Muvaffaqiyatsiz" else if (tx.kind == "request") "So'rov" else timeLabel(tx.time), 14,
                    color = if (failed) Red else Grey
                )
            }
        }
    }
}

@Composable
fun PinPad(title: String, subtitle: String, error: String?, onComplete: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(40.dp))
        ClickMark(60.dp, Blue, Bg)
        Spacer(Modifier.height(20.dp))
        T(title, 26, FontWeight.Bold, align = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        T(subtitle, 16, color = Grey, align = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            repeat(4) { i -> Box(Modifier.size(18.dp).clip(CircleShape).background(if (i < pin.length) Blue else DisabledGrey)) }
        }
        Spacer(Modifier.height(16.dp))
        T(error ?: "", 15, color = Red, align = TextAlign.Center)
        Spacer(Modifier.weight(1f))
        val keys = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<"))
        keys.forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { k ->
                    if (k.isEmpty()) {
                        Spacer(Modifier.size(76.dp))
                    } else {
                        Box(
                            Modifier.size(76.dp).clip(CircleShape).background(Color.White).clickable {
                                if (k == "<") {
                                    if (pin.isNotEmpty()) pin = pin.dropLast(1)
                                } else if (pin.length < 4) {
                                    pin += k
                                    if (pin.length == 4) {
                                        val p = pin
                                        pin = ""
                                        onComplete(p)
                                    }
                                }
                            },
                            contentAlignment = Alignment.Center
                        ) {
                            if (k == "<") Icon(Icons.AutoMirrored.Filled.Backspace, null, tint = Ink)
                            else T(k, 30, FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}
