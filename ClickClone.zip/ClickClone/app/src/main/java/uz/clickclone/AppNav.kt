package uz.clickclone

import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = "splash",
        enterTransition = { slideInHorizontally(tween(260)) { it / 6 } + fadeIn(tween(260)) },
        exitTransition = { fadeOut(tween(160)) },
        popEnterTransition = { fadeIn(tween(200)) },
        popExitTransition = { slideOutHorizontally(tween(240)) { it / 6 } + fadeOut(tween(200)) }
    ) {
        composable("splash") {
            SplashScreen { dest -> nav.navigate(dest) { popUpTo("splash") { inclusive = true } } }
        }
        composable("phone") { PhoneScreen(onNext = { nav.navigate("sms") }) }
        composable("sms") { SmsScreen(onBack = { nav.popBackStack() }, onOk = { nav.navigate("pinCreate") }) }
        composable("pinCreate") {
            PinCreateScreen(onDone = { nav.navigate("main") { popUpTo(nav.graph.id) { inclusive = true } } })
        }
        composable("pinLogin") {
            PinLoginScreen(
                onOk = { nav.navigate("main") { popUpTo(nav.graph.id) { inclusive = true } } },
                onReset = {
                    Store.resetAll()
                    nav.navigate("phone") { popUpTo(nav.graph.id) { inclusive = true } }
                }
            )
        }
        composable("main") { MainScreen(nav) }
        composable("category") { CategoryScreen(nav) }
        composable("payForm") { PayFormScreen(nav) }
        composable("transfer") { TransferScreen(nav) }
        composable("topup") { TopUpScreen(nav) }
        composable("result") { ResultScreen(nav) }
        composable("receipt") { ReceiptScreen(nav) }
        composable("history") { HistoryScreen(nav) }
        composable("notifications") { NotificationsScreen(nav) }
        composable("cards") { CardsScreen(nav) }
        composable("profile") {
            ProfileScreen(nav, onLogout = {
                Store.logout()
                nav.navigate("pinLogin") { popUpTo(nav.graph.id) { inclusive = true } }
            })
        }
        composable("settings") { SettingsScreen(nav) }
    }
}
