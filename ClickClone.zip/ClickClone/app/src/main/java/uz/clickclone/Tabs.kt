package uz.clickclone

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.navigation.NavController
import java.util.Calendar

fun openTransfer(nav: NavController, mode: String, contact: Contact? = null, account: String = "") {
    Flow.transferMode = mode
    Flow.contact = contact
    Flow.prefillAccount = account
    nav.navigate("transfer")
}

fun openService(nav: NavController, cat: String, svc: Svc, account: String = "", amount: String = "") {
    Flow.category = cat
    Flow.service = svc.name
    Flow.svcSub = svc.sub
    Flow.prefillAccount = account
    Flow.prefillAmount = amount
    nav.navigate("payForm")
}

@Composable
fun MainScreen(nav: NavController) {
    var tab by rememberSaveable { mutableStateOf(0) }
    BackHandler(enabled = tab != 0) { tab = 0 }
    ScreenRoot(imeAware = false, bottomInset = false) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> HomeTab(nav) { tab = it }
                1 -> PayTab(nav)
                2 -> TransferTab(nav)
                3 -> ReportsTab(nav)
                else -> MiniAppsTab(nav)
            }
        }
        BottomBar(tab) { tab = it }
    }
}

@Composable
fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    val labels = listOf("Asosiy", "To'lov", "O'tkazma", "Hisobotlar", "Mini Apps")
    val icons = listOf<ImageVector?>(
        null, Icons.Filled.AccountBalanceWallet, Icons.Filled.SwapVert, Icons.Filled.PieChart, Icons.Filled.Apps
    )
    Row(Modifier.fillMaxWidth().background(Color.White).navigationBarsPadding().padding(top = 8.dp, bottom = 6.dp)) {
        labels.forEachIndexed { i, label ->
            val c = if (sel == i) Blue else Grey
            Column(
                Modifier.weight(1f).clickable { onSel(i) }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.height(36.dp), contentAlignment = Alignment.Center) {
                    val ic = icons[i]
                    if (ic == null) ClickMark(40.dp, c, Color.White) else Icon(ic, null, tint = c, modifier = Modifier.size(32.dp))
                    if (i == 4) {
                        Box(
                            Modifier.align(Alignment.TopEnd).offset(x = 22.dp, y = (-6).dp).clip(RoundedCornerShape(50))
                                .background(Orange).padding(horizontal = 6.dp, vertical = 2.dp)
                        ) { T("New", 10, FontWeight.Bold, Color.White) }
                    }
                }
                T(label, 12, color = c, maxLines = 1)
            }
        }
    }
}

// ---------------------------------------------------------------- HOME

@Composable
fun HomeTab(nav: NavController, goTab: (Int) -> Unit) {
    var dlg by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(52.dp).clip(CircleShape).background(Color.White).clickable { nav.navigate("profile") },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Person, null, tint = Blue, modifier = Modifier.size(32.dp)) }
            Spacer(Modifier.width(12.dp))
            Row(
                Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(16.dp)).background(Color.White)
                    .clickable { openTransfer(nav, "manual") }.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.CreditCard, null, tint = Grey)
                Spacer(Modifier.width(12.dp))
                T("Kartaga o'tkazma", 19, color = DisabledGrey)
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(48.dp).clip(CircleShape).clickable { nav.navigate("notifications") }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Notifications, null, tint = Blue, modifier = Modifier.size(30.dp))
                Box(Modifier.align(Alignment.TopEnd).padding(top = 8.dp, end = 10.dp).size(10.dp).clip(CircleShape).background(Orange))
            }
        }
        Spacer(Modifier.height(24.dp))
        T("Umumiy balans", 17, color = Grey)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                if (Store.hideBalance) T("•••• so'm", 40, FontWeight.Bold) else Money(fmt(Store.total()), 42)
            }
            Icon(
                if (Store.hideBalance) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null, tint = Grey,
                modifier = Modifier.size(34.dp).clip(CircleShape).clickable { Store.hideBalance = !Store.hideBalance; Store.save() }
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T("Mening hamyonim", 17, color = Grey)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ClickMark(36.dp, Blue, Bg)
                    Spacer(Modifier.width(6.dp))
                    val w = Store.cards.getOrNull(1)
                    Money(if (Store.hideBalance) "••••" else fmt(w?.balance ?: 0L), 26)
                }
            }
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(Orange).clickable { dlg = "demo" }.padding(horizontal = 26.dp, vertical = 14.dp)
            ) { Text("DEMO", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic) }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickTile(Icons.Filled.Menu, "Click\nPass", Modifier.weight(1f)) { dlg = "pass" }
            QuickTile(Icons.Filled.Phone, "Click\nBoom", Modifier.weight(1f)) { dlg = "boom" }
            QuickTile(Icons.Filled.CreditCard, "Kartalar va\nhamyon", Modifier.weight(1f)) { nav.navigate("cards") }
            QuickTile(Icons.Filled.QrCodeScanner, "QR\nskaner", Modifier.weight(1f)) { dlg = "qr" }
        }
        Spacer(Modifier.height(16.dp))
        WCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("notifications") }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Blue), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Star, null, tint = Color.White)
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    T("Mening Click", 22, FontWeight.Medium)
                    T("Muhim voqealarni ko'ring", 16, color = Grey)
                }
                Icon(Icons.Filled.KeyboardArrowRight, null, tint = Grey)
            }
        }
        Spacer(Modifier.height(16.dp))
        WCard(Modifier.fillMaxWidth(), onClick = { goTab(1) }) {
            Row(Modifier.padding(horizontal = 24.dp, vertical = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "OYLIK\nTO'LOVLARNI\nUNUTMANG", color = Blue, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold,
                    fontStyle = FontStyle.Italic, lineHeight = 30.sp, modifier = Modifier.weight(1f)
                )
                Icon(Icons.Filled.Bolt, null, tint = Orange, modifier = Modifier.size(84.dp))
            }
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Mini Apps", 26, FontWeight.Bold, modifier = Modifier.weight(1f))
            T("Barchasi", 20, color = Blue, modifier = Modifier.clickable { goTab(4) })
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniTile("Click Avto", Icons.Filled.DirectionsCar, Color(0xFF22B14C), Modifier.weight(1f)) { dlg = "Click Avto" }
            MiniTile("Click Uyim", Icons.Filled.Lock, Color(0xFF8A3CF2), Modifier.weight(1f)) { dlg = "Click Uyim" }
            MiniTile("Inson Uchun", Icons.Filled.Favorite, Orange, Modifier.weight(1f)) { dlg = "Inson Uchun" }
            MiniTile("Click Obuna", Icons.Filled.Refresh, Color(0xFF3A3A3A), Modifier.weight(1f)) { dlg = "Click Obuna" }
        }
        Spacer(Modifier.height(24.dp))
    }
    dlg?.let { d ->
        val msg = when (d) {
            "demo" -> "Bu Click Clone demo ilovasi. Barcha balans va to'lovlar faqat shu telefonda saqlanadigan sinov ma'lumotlari. Haqiqiy pul ishlatilmaydi."
            "pass" -> "Click Pass demo rejimida ishlamaydi."
            "boom" -> "Click Boom demo rejimida ishlamaydi."
            "qr" -> "QR skaner demo rejimida o'chirilgan (kamera ishlatilmaydi)."
            else -> "$d mini ilovasi demo rejimida ochilmaydi."
        }
        InfoDialog(if (d.length > 8) d else "Demo", msg) { dlg = null }
    }
}

@Composable
fun QuickTile(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    WCard(modifier.height(112.dp), onClick = onClick) {
        Column(Modifier.fillMaxSize().padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(38.dp))
            Spacer(Modifier.height(8.dp))
            T(label, 14, align = TextAlign.Center)
        }
    }
}

@Composable
fun MiniTile(label: String, icon: ImageVector, tint: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(6.dp))
        T(label, 14, align = TextAlign.Center, maxLines = 1)
    }
}

// ---------------------------------------------------------------- PAY

data class Cat(val name: String, val icon: ImageVector)

val payCats = listOf(
    Cat("Mobil operatorlar", Icons.Filled.SignalCellularAlt),
    Cat("Internet va TV", Icons.Filled.Wifi),
    Cat("Davlat xizmatlari va DYHXX (GAI)", Icons.Filled.AccountBalance),
    Cat("Kommunal to'lovlar", Icons.Filled.Bolt),
    Cat("Mikrokredit va muddatli to'lovlar", Icons.Filled.Percent)
)

@Composable
fun PayTab(nav: NavController) {
    var q by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        T("To'lov", 26, FontWeight.Bold, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        SearchBox(q, { q = it }) {
            Icon(Icons.Filled.QrCodeScanner, null, tint = Blue, modifier = Modifier.size(30.dp).clickable { dlg = "qr" })
        }
        Spacer(Modifier.height(20.dp))
        if (q.isNotBlank()) {
            val found = catalog.flatMap { (cat, list) -> list.map { cat to it } }.filter { it.second.name.contains(q, true) }
            if (found.isEmpty()) T("Hech narsa topilmadi", 16, color = Grey)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                found.forEach { (cat, svc) ->
                    WCard(Modifier.fillMaxWidth(), onClick = { openService(nav, cat, svc) }) {
                        Column(Modifier.padding(16.dp)) { T(svc.name, 19, FontWeight.Medium); T(svc.sub, 14, color = Grey) }
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ShortcutItem(Icons.Filled.DateRange, Orange, "Avtoto'lovlar") { dlg = "Avtoto'lovlar" }
                ShortcutItem(Icons.Filled.Star, Color(0xFF8A3CF2), "Tanlangan\nto'lovlar") { dlg = "Tanlangan to'lovlar" }
                ShortcutItem(Icons.Filled.Receipt, Blue, "To'lovga\nhisoblar") { dlg = "To'lovga hisoblar" }
                ShortcutItem(Icons.Filled.LocationOn, Color(0xFF12B76A), "Joyda\nto'lov") { dlg = "Joyda to'lov" }
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SavedTile("MyXvest.ru", "14043", 4800L) { openService(nav, "Internet va TV", Svc("MyXvest.ru", "Xosting va domenlar"), "14043", "4800") }
                SavedTile("Sayt.uz", "14535", 14200L) { openService(nav, "Internet va TV", Svc("Sayt.uz", "Xosting va domenlar"), "14535", "14200") }
                SavedTile("Ucell", "949807008", 500L) { openService(nav, "Mobil operatorlar", Svc("Ucell", "Mobil aloqa"), "949807008", "500") }
            }
            Spacer(Modifier.height(20.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                payCats.forEach { c ->
                    WCard(Modifier.fillMaxWidth(), onClick = { Flow.category = c.name; nav.navigate("category") }) {
                        Row(Modifier.padding(horizontal = 20.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(c.icon, null, tint = Blue, modifier = Modifier.size(34.dp))
                            Spacer(Modifier.width(18.dp))
                            T(c.name, 22, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
    dlg?.let { d ->
        InfoDialog(if (d == "qr") "QR skaner" else d, if (d == "qr") "Kamera demo rejimida o'chirilgan." else "Bu bo'lim demo rejimida mavjud emas.") { dlg = null }
    }
}

@Composable
fun ShortcutItem(icon: ImageVector, tint: Color, label: String, onClick: () -> Unit) {
    Column(
        Modifier.width(86.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(48.dp))
        Spacer(Modifier.height(8.dp))
        T(label, 14, align = TextAlign.Center)
    }
}

@Composable
fun SavedTile(name: String, acc: String, amount: Long, onClick: () -> Unit) {
    WCard(Modifier.width(190.dp), onClick = onClick) {
        Column(Modifier.padding(16.dp)) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(Bg), contentAlignment = Alignment.Center) {
                T(name.take(1), 20, FontWeight.Bold, Blue)
            }
            Spacer(Modifier.height(10.dp))
            T(name, 20, FontWeight.Bold, maxLines = 1)
            T(acc, 16)
            T(fmt(amount) + " so'm", 16, color = Grey)
        }
    }
}

// ---------------------------------------------------------------- TRANSFER

@Composable
fun TransferTab(nav: NavController) {
    var q by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf(false) }
    val digits = q.filter { it.isDigit() }
    val valid = digits.length in listOf(9, 12, 16)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        T("O'tkazmalar", 26, FontWeight.Bold, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Row(
            Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(16.dp)).background(Color.White)
                .border(1.5.dp, DisabledGrey, RoundedCornerShape(16.dp)).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f)) {
                if (q.isEmpty()) T("Karta, hamyon yoki telefon raqami", 16, color = Grey, maxLines = 1)
                BasicTextField(
                    q, { q = it.take(24) }, singleLine = true,
                    textStyle = TextStyle(fontSize = 18.sp, color = Ink),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    cursorBrush = SolidColor(Blue), modifier = Modifier.fillMaxWidth()
                )
            }
            Icon(Icons.Filled.AccountCircle, null, tint = Blue, modifier = Modifier.size(36.dp).clip(CircleShape).clickable { dlg = "Kontaktlar" })
            Spacer(Modifier.width(14.dp))
            Icon(Icons.Filled.QrCodeScanner, null, tint = Blue, modifier = Modifier.size(34.dp).clickable { dlg = "QR skaner" })
        }
        if (valid) {
            Spacer(Modifier.height(12.dp))
            BigButton("Davom etish") { openTransfer(nav, "manual", account = digits) }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OpTile(Icons.Filled.SwapHoriz, "Kartalarim\norasida") { openTransfer(nav, "own") }
            OpTile(Icons.Filled.Phone, "Pul\nso'rash") { openTransfer(nav, "request") }
            OpTile(Icons.Filled.Share, "Qarzga\nberish") { openTransfer(nav, "loan") }
            OpTile(Icons.Filled.History, "O'tkazmalar\ntarixi") { nav.navigate("history") }
        }
        Spacer(Modifier.height(16.dp))
        WCard(Modifier.fillMaxWidth(), onClick = { openTransfer(nav, "manual") }) {
            Row(Modifier.padding(horizontal = 20.dp, vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Phone, null, tint = Blue, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(18.dp))
                T("Telefon raqami orqali", 22, modifier = Modifier.weight(1f))
                Icon(Icons.Filled.KeyboardArrowRight, null, tint = Ink)
            }
        }
        Spacer(Modifier.height(24.dp))
        val favs = demoContacts.filter { Store.favorites.contains(it.name) }
        val others = demoContacts.filter { !Store.favorites.contains(it.name) }
        if (favs.isNotEmpty()) {
            T("Saralanganlar", 22, FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            favs.forEach { c -> ContactRow(c, nav, { info = true }); Spacer(Modifier.height(10.dp)) }
        }
        if (others.isNotEmpty()) {
            T("Oxirgilar", 16, color = Grey)
            Spacer(Modifier.height(10.dp))
            others.forEach { c -> ContactRow(c, nav, { info = true }); Spacer(Modifier.height(10.dp)) }
        }
        Spacer(Modifier.height(24.dp))
    }
    dlg?.let { d -> InfoDialog(d, if (d == "Kontaktlar") "Demo rejimida telefon kontaktlari ulanmagan. Saralanganlar ro'yxatidan tanlang." else "Kamera demo rejimida o'chirilgan.") { dlg = null } }
    if (info) InfoDialog("Tahrirlash", "Kontaktni tahrirlash demo rejimida mavjud emas.") { info = false }
}

@Composable
fun OpTile(icon: ImageVector, label: String, onClick: () -> Unit) {
    WCard(Modifier.width(140.dp).height(120.dp), onClick = onClick) {
        Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(36.dp))
            Spacer(Modifier.height(8.dp))
            T(label, 16, align = TextAlign.Center)
        }
    }
}

@Composable
fun ContactRow(c: Contact, nav: NavController, onEdit: () -> Unit) {
    val fav = Store.favorites.contains(c.name)
    WCard(Modifier.fillMaxWidth(), onClick = { openTransfer(nav, "contact", c) }) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            InitialsAvatar(c.initials, 60.dp)
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    T(c.name, 20, FontWeight.Bold)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Filled.Verified, null, tint = Blue, modifier = Modifier.size(22.dp))
                }
                T(c.mask, 19, color = Grey)
            }
            Icon(Icons.Filled.Edit, null, tint = Grey, modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onEdit).padding(4.dp))
            Spacer(Modifier.width(8.dp))
            Icon(
                if (fav) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = Grey,
                modifier = Modifier.size(36.dp).clip(CircleShape).clickable { Store.toggleFavorite(c.name) }.padding(4.dp)
            )
        }
    }
}

// ---------------------------------------------------------------- REPORTS

@Composable
fun ChipMenu(label: String, options: List<String>, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.clip(RoundedCornerShape(28.dp)).background(Color.White).clickable { open = true }.padding(horizontal = 22.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            T(label, 18)
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Filled.KeyboardArrowDown, null, tint = Blue)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEachIndexed { i, o -> DropdownMenuItem(text = { T(o, 16) }, onClick = { open = false; onPick(i) }) }
        }
    }
}

fun historyText(list: List<Tx>): String {
    val sb = StringBuilder("CLICK CLONE - DEMO HISOBOT (haqiqiy emas)\n\n")
    list.forEach {
        sb.append("${fullLabel(it.time)} | ${it.title} | ${fmt(it.amount)} so'm | ${it.status} | #${it.id}\n")
    }
    return sb.toString()
}

@Composable
fun ReportsTab(nav: NavController) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var q by remember { mutableStateOf("") }
    var cardF by remember { mutableStateOf<String?>(null) }
    var cardLabel by remember { mutableStateOf("Kartalar") }
    var typeF by remember { mutableIntStateOf(0) }
    var perF by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf<String?>(null) }
    val now = Calendar.getInstance()
    fun inMonth(t: Long): Boolean {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        return c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && c.get(Calendar.MONTH) == now.get(Calendar.MONTH)
    }
    val monthName = monthNames[now.get(Calendar.MONTH)].replaceFirstChar { it.uppercase() }
    val counted = Store.txs.filter { it.status == "Muvaffaqiyatli" && it.kind != "own" && it.kind != "request" && inMonth(it.time) }
    val inc = counted.filter { it.amount > 0 }.sumOf { it.amount }
    val exp = -counted.filter { it.amount < 0 }.sumOf { it.amount }
    val list = Store.txs.filter { t ->
        val isInc = t.amount > 0 && t.kind != "request"
        (cardF == null || t.cardId == cardF) &&
            (typeF == 0 || (typeF == 1 && isInc) || (typeF == 2 && t.amount < 0)) &&
            (perF == 0 || inMonth(t.time)) &&
            (q.isBlank() || t.title.contains(q, true) || t.subtitle.contains(q, true))
    }
    val groups = list.groupBy { dayLabel(it.time) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Hisobotlar", 32, FontWeight.Bold, modifier = Modifier.weight(1f))
            Icon(
                Icons.Filled.Share, null, tint = Blue,
                modifier = Modifier.size(44.dp).clip(CircleShape).clickable {
                    val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, historyText(Store.txs.toList()))
                    }
                    ctx.startActivity(android.content.Intent.createChooser(i, "Demo hisobotni yuborish"))
                }.padding(8.dp)
            )
            Icon(
                Icons.Filled.PieChart, null, tint = Blue,
                modifier = Modifier.size(44.dp).clip(CircleShape).clickable { dlg = "chart" }.padding(8.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        SearchBox(q, { q = it })
        Spacer(Modifier.height(14.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ChipMenu(cardLabel, listOf("Barcha kartalar") + Store.cards.map { it.bank + " *" + it.number.takeLast(4) }) { i ->
                if (i == 0) { cardF = null; cardLabel = "Kartalar" } else { cardF = Store.cards[i - 1].id; cardLabel = Store.cards[i - 1].bank }
            }
            ChipMenu(listOf("Operatsiya turi", "Tushum", "Xarajat")[typeF], listOf("Hammasi", "Tushum", "Xarajat")) { typeF = it }
            ChipMenu(listOf("Davr", "Shu oy")[perF], listOf("Hammasi", "Shu oy")) { perF = it }
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            WCard(Modifier.weight(1f)) {
                Column(Modifier.padding(16.dp)) {
                    T("$monthName uchun tushumlar", 14, color = Grey, maxLines = 1)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Add, null, tint = GreenOk, modifier = Modifier.size(22.dp))
                        Money(fmt(inc), 22)
                    }
                }
            }
            WCard(Modifier.weight(1f)) {
                Column(Modifier.padding(16.dp)) {
                    T("$monthName uchun xarajatlar", 14, color = Grey, maxLines = 1)
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Remove, null, tint = Orange, modifier = Modifier.size(22.dp))
                        Money(fmt(exp), 22)
                    }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        WCard(Modifier.fillMaxWidth(), onClick = { dlg = "monitor" }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape).background(Blue), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.History, null, tint = Color.White, modifier = Modifier.size(26.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T("Monitoringni ulang", 22, FontWeight.Bold)
                    T("Faqat Click orqali amalga oshirilgan operatsiyalar ko'rsatiladi", 16, color = Grey)
                }
                Icon(Icons.Filled.KeyboardArrowRight, null, tint = Grey)
            }
        }
        Spacer(Modifier.height(20.dp))
        if (list.isEmpty()) T("Hozircha tranzaksiyalar yo'q", 17, color = Grey, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
        groups.forEach { (day, items) ->
            val spent = -items.filter { it.status == "Muvaffaqiyatli" && it.kind != "request" && it.amount < 0 }.sumOf { it.amount }
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    T(day, 26, FontWeight.Bold)
                    T("Sarflangan", 17, color = Grey)
                }
                T(if (spent > 0) "- ${fmt(spent)} so'm" else "0 so'm", 17, color = Grey)
            }
            Spacer(Modifier.height(10.dp))
            items.forEach { t ->
                TxRow(t) { Flow.receiptId = t.id; nav.navigate("receipt") }
                Spacer(Modifier.height(10.dp))
            }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(16.dp))
    }
    dlg?.let { d ->
        if (d == "chart") InfoDialog("Diagramma", "Tushum: ${fmt(inc)} so'm\nXarajat: ${fmt(exp)} so'm\n(shu oy, demo ma'lumotlar)") { dlg = null }
        else InfoDialog("Monitoring", "Demo rejimida barcha operatsiyalar Click Clone ichida yoziladi.") { dlg = null }
    }
}

// ---------------------------------------------------------------- MINI APPS

val miniData = mapOf(
    "Tushlik" to listOf("Koz Moon" to "Ko'zmunchoq taqinchoqlar", "Demo Oshxona" to "Tushlik buyurtmasi"),
    "Transport" to listOf("Demo Taksi" to "Shahar bo'ylab taksi", "Demo Avtobus" to "Chipta xaridi"),
    "Ovqat" to listOf("Demo Pitsa" to "Pitsa yetkazish", "Demo Burger" to "Fast-food"),
    "Xarid" to listOf("Demo Market" to "Oziq-ovqat", "Demo Do'kon" to "Elektronika")
)

@Composable
fun MiniAppsTab(nav: NavController) {
    var region by remember { mutableStateOf("Barcha hududlar") }
    var regionOpen by remember { mutableStateOf(false) }
    var chip by remember { mutableStateOf("Tushlik") }
    var dlg by remember { mutableStateOf<String?>(null) }
    var q by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("Mini Apps", 36, FontWeight.Bold, modifier = Modifier.weight(1f))
            Box {
                Row(Modifier.clickable { regionOpen = true }, verticalAlignment = Alignment.CenterVertically) {
                    T(region, 20, color = Blue)
                    Icon(Icons.Filled.KeyboardArrowDown, null, tint = Blue)
                }
                DropdownMenu(expanded = regionOpen, onDismissRequest = { regionOpen = false }) {
                    listOf("Barcha hududlar", "Toshkent", "Namangan", "Samarqand", "Farg'ona").forEach { r ->
                        DropdownMenuItem(text = { T(r, 16) }, onClick = { region = r; regionOpen = false })
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        SearchBox(q, { q = it })
        Spacer(Modifier.height(16.dp))
        WCard(Modifier.fillMaxWidth(), onClick = { dlg = "Vidjetni sozlash demo rejimida mavjud emas." }) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Apps, null, tint = Blue, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    T("Asosiydagi Mini Apps", 22, FontWeight.Bold)
                    T("Vidjetni sozlash", 18, color = Grey)
                }
                Icon(Icons.Filled.KeyboardArrowRight, null, tint = Grey)
            }
        }
        Spacer(Modifier.height(20.dp))
        T("Mening Clickim", 24, FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniTile("Click Uyim", Icons.Filled.Lock, Color(0xFF8A3CF2), Modifier.weight(1f)) { dlg = "Click Uyim demo rejimida ochilmaydi." }
            MiniTile("Yashil Meros", Icons.Filled.Favorite, Color(0xFF22B14C), Modifier.weight(1f)) { dlg = "Yashil Meros demo rejimida ochilmaydi." }
            MiniTile("Click Avto", Icons.Filled.DirectionsCar, Color(0xFF22B14C), Modifier.weight(1f)) { dlg = "Click Avto demo rejimida ochilmaydi." }
            MiniTile("Mening Oilam", Icons.Filled.Person, Orange, Modifier.weight(1f)) { dlg = "Mening Oilam demo rejimida ochilmaydi." }
        }
        Spacer(Modifier.height(20.dp))
        T("To'lovlar", 24, FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniTile("Kartalar monitoringi", Icons.Filled.History, Blue, Modifier.weight(1f)) { nav.navigate("cards") }
            MiniTile("Avtoto'lovlar", Icons.Filled.DateRange, Orange, Modifier.weight(1f)) { dlg = "Avtoto'lovlar demo rejimida mavjud emas." }
            MiniTile("Tanlangan to'lovlar", Icons.Filled.Star, Color(0xFF8A3CF2), Modifier.weight(1f)) { dlg = "Tanlangan to'lovlar demo rejimida mavjud emas." }
            MiniTile("Joyda to'lov", Icons.Filled.LocationOn, Color(0xFF12B76A), Modifier.weight(1f)) { dlg = "Joyda to'lov demo rejimida mavjud emas." }
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            miniData.keys.forEach { k ->
                val sel = chip == k
                Box(
                    Modifier.clip(RoundedCornerShape(30.dp)).background(if (sel) Blue else Color.White)
                        .clickable { chip = k }.padding(horizontal = 28.dp, vertical = 18.dp)
                ) { T(k, 20, color = if (sel) Color.White else Ink) }
            }
        }
        Spacer(Modifier.height(16.dp))
        (miniData[chip] ?: emptyList()).filter { q.isBlank() || it.first.contains(q, true) }.forEach { (n, d) ->
            WCard(Modifier.fillMaxWidth(), onClick = { dlg = "$n demo rejimida ochilmaydi." }) {
                Column(Modifier.padding(20.dp)) { T(n, 22, FontWeight.Bold); T(d, 18, color = Grey) }
            }
            Spacer(Modifier.height(10.dp))
        }
        Spacer(Modifier.height(24.dp))
    }
    dlg?.let { InfoDialog("Demo", it) { dlg = null } }
}
