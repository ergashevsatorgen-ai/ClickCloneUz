package uz.clickclone

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

const val DEMO_SMS_CODE = "12345"

@Composable
fun SplashScreen(go: (String) -> Unit) {
    LaunchedEffect(Unit) {
        delay(1300)
        go(if (Store.registered) "pinLogin" else "phone")
    }
    Box(Modifier.fillMaxSize().background(Blue), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ClickMark(96.dp, Color.White, Blue)
            Spacer(Modifier.width(12.dp))
            T("click", 72, FontWeight.ExtraBold, Ink)
        }
        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            T("CLONE  •  DEMO", 14, FontWeight.Bold, Color.White.copy(alpha = 0.85f))
        }
    }
}

@Composable
fun PhoneScreen(onNext: () -> Unit) {
    var d by remember { mutableStateOf("") }
    ScreenRoot {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Spacer(Modifier.height(32.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ClickMark(48.dp, Blue, Bg)
                Spacer(Modifier.width(10.dp))
                T("Click Clone", 28, FontWeight.ExtraBold)
                Spacer(Modifier.width(10.dp))
                DemoChip()
            }
            Spacer(Modifier.height(40.dp))
            T("Telefon raqamingizni kiriting", 26, FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            T("Demo rejim: haqiqiy SMS yuborilmaydi. Istalgan 9 xonali raqam ishlaydi.", 15, color = Grey)
            Spacer(Modifier.height(24.dp))
            WCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 16.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    T("+998", 22, FontWeight.Medium)
                    Spacer(Modifier.width(12.dp))
                    Box(Modifier.weight(1f)) {
                        if (d.isEmpty()) T("90 123 45 67", 22, color = DisabledGrey)
                        BasicTextField(
                            d, { d = it.filter { c -> c.isDigit() }.take(9) }, singleLine = true,
                            textStyle = TextStyle(fontSize = 22.sp, color = Ink, fontWeight = FontWeight.Medium),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            cursorBrush = SolidColor(Blue), modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            BigButton("Davom etish", enabled = d.length == 9) {
                Store.phone = "+998$d"
                onNext()
            }
        }
    }
}

@Composable
fun SmsScreen(onBack: () -> Unit, onOk: () -> Unit) {
    var code by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    ScreenRoot {
        TopBar("Tasdiqlash", onBack)
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            T("${Store.phone} raqamiga demo kod yuborildi", 20, FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                DemoChip(); Spacer(Modifier.width(8.dp))
                T("Demo SMS-kod: $DEMO_SMS_CODE", 16, FontWeight.Medium, Blue)
            }
            Spacer(Modifier.height(24.dp))
            WCard(Modifier.fillMaxWidth()) {
                Box(Modifier.padding(20.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    if (code.isEmpty()) T("• • • • •", 30, color = DisabledGrey)
                    BasicTextField(
                        code,
                        {
                            code = it.filter { c -> c.isDigit() }.take(5)
                            err = null
                            if (code.length == 5) {
                                if (code == DEMO_SMS_CODE) onOk() else { err = "Kod noto'g'ri. Demo kod: $DEMO_SMS_CODE"; code = "" }
                            }
                        },
                        singleLine = true,
                        textStyle = TextStyle(fontSize = 30.sp, color = Ink, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, letterSpacing = 8.sp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        cursorBrush = SolidColor(Blue), modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            if (err != null) T(err ?: "", 15, color = Red)
        }
    }
}

@Composable
fun PinCreateScreen(onDone: () -> Unit) {
    var first by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    ScreenRoot {
        PinPad(
            if (first == null) "PIN-kod yarating" else "PIN-kodni takrorlang",
            "Demo ilova uchun 4 xonali PIN-kod", err
        ) { p ->
            val f = first
            if (f == null) {
                first = p; err = null
            } else if (f == p) {
                Store.registerUser(Store.phone, p)
                onDone()
            } else {
                first = null; err = "PIN-kodlar mos kelmadi. Qaytadan kiriting."
            }
        }
    }
}

@Composable
fun PinLoginScreen(onOk: () -> Unit, onReset: () -> Unit) {
    var err by remember { mutableStateOf<String?>(null) }
    ScreenRoot {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                PinPad("PIN-kodni kiriting", "Click Clone (demo) ${Store.phone}", err) { p ->
                    if (Store.checkPin(p)) {
                        Store.unlocked = true
                        onOk()
                    } else err = "PIN-kod noto'g'ri"
                }
            }
            TextButton(onClick = onReset, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                T("PIN esdan chiqdimi? Demo ma'lumotlarni o'chirish", 14, color = Grey)
            }
        }
    }
}
